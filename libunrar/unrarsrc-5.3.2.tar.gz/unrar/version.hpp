#define RARVER_MAJOR     5
#define RARVER_MINOR    30
#define RARVER_BETA      2
#define RARVER_DAY       4
#define RARVER_MONTH     8
#define RARVER_YEAR   2015
